// === One Piece Story Mode Mod - FINAL BUILD ===

const playerXP = {};
const playerBerry = {};
const playersWithFruit = {};
const playerRevealedBerry = {};

function getXP(player) {
  return playerXP[player.getID()] || 0;
}

function addXP(player, amount, message) {
  let id = player.getID();
  playerXP[id] = getXP(player) + amount;
  player.sendMessage(`+${amount} XP! ${message}`);
}

function getBerry(player) {
  return playerBerry[player.getID()] || 0;
}

function addBerry(player, amount) {
  let id = player.getID();
  playerBerry[id] = getBerry(player) + amount;
}

function eatDevilFruit(player, fruitEffect) {
  let id = player.getID();
  if (playersWithFruit[id]) {
    player.sendMessage("You already ate a Devil Fruit!");
    return;
  }
  player.addEffect(fruitEffect, 600);
  playersWithFruit[id] = fruitEffect;
  player.sendMessage("You ate the " + fruitEffect.replace("_power", "") + " Fruit!");
}

function getBerryDisplay(player) {
  return playerRevealedBerry[player.getID()] ? "Berry: " + getBerry(player) : "Berry: ???";
}

// === XP EVENTS ===
game.onEntityKilled(function(player, target) {
  if (target.id === "pirate_king") return addXP(player, 100000, "THE HOLY GRAIL!!");
  if (target.location === "land") return addXP(player, 10, "SORRY SUCKER");
  if (target.location === "ocean") return addXP(player, 50, "that's mid rizz bro...");
  if (target.hasEffect("devil_fruit_user")) return addXP(player, 100, "still not a lot...");
});

function onGearUsed(player) {
  addXP(player, 500, "COUGH, STILL A LOSER *ACHEM!*");
}

// === SELL DEVIL FRUITS ===
function sellDevilFruits(player) {
  let inventory = player.getInventory();
  let count = 0;
  inventory.forEach((item, i) => {
    if (item && item.id && item.id.endsWith("_no_mi")) {
      count++;
      inventory[i] = null;
    }
  });
  if (count > 0) {
    let total = count * 1000;
    addBerry(player, total);
    playerRevealedBerry[player.getID()] = true;
    player.sendMessage("Sold " + count + " Devil Fruits for " + total + " Berry!");
  } else {
    const roasts = [
      "What is this junk? You tryna scam me?",
      "That's not a Devil Fruit — it's a coconut with Sharpie!",
      "Get lost, I sell quality only!",
      "You call that a fruit? My grandma has better snacks!"
    ];
    player.sendMessage("🧂 Fruit Merchant: " + roasts[Math.floor(Math.random() * roasts.length)]);
  }
  player.sendMessage("💰 Current Berry: " + getBerryDisplay(player));
}

function spawnFruitMerchant(x, y, z) {
  game.spawnMob("fruit_merchant", {
    x: x,
    y: y,
    z: z,
    displayName: "🍌 Fruit Merchant",
    texture: "textures/character/Wapol.png",
    health: 50,
    onInteract: function(player) {
      sellDevilFruits(player);
    }
  });
}

// === Luffy Crew Rules ===
const onePieceCharacters = [
  { id: "zoro", texture: "textures/characters/Zoro.png", health: 80, damage: 0, xpRequired: 0, isFriendly: true },
  { id: "sanji", texture: "textures/characters/Sanji.png", health: 80, damage: 0, xpRequired: 0, isFriendly: true },
  { id: "usopp", texture: "textures/characters/Ussop.png", health: 70, damage: 0, xpRequired: 0, isFriendly: true },
  { id: "luffy", texture: "textures/characters/Luffy.png", health: 120, damage: 14, xpRequired: 100, isFriendly: true, isUltraRare: true, forbiddenEffect: "rubber_power" },
  { id: "blackbeard", texture: "textures/characters/Blackbeard.png", health: 160, damage: 18, xpRequired: 100 },
  { id: "akainu", texture: "textures/characters/Akainu.png", health: 200, damage: 20, xpRequired: 150 },
  { id: "whitebeard", texture: "textures/characters/Whitebeard.png", health: 250, damage: 25, xpRequired: 200 },
  { id: "alvida", texture: "textures/characters/Alvida.png", health: 60, damage: 6, xpRequired: 0 },
  { id: "aokiji", texture: "textures/characters/Aokiji.png", health: 180, damage: 16, xpRequired: 120 }
];

function spawnRandomCharactersAcrossOcean() {
  game.players.forEach(player => {
    let xp = getXP(player);
    let id = player.getID();
    let hasGomu = playersWithFruit[id] === "rubber_power";
    for (let i = 0; i < 10; i++) {
      let char = onePieceCharacters[Math.floor(Math.random() * onePieceCharacters.length)];
      if (xp >= char.xpRequired) {
        if (char.isUltraRare && hasGomu) continue;
        let x = player.x + Math.floor(Math.random() * 100) - 50;
        let z = player.z + Math.floor(Math.random() * 100) - 50;
        let y = game.getSurfaceY(x, z);
        game.spawnMob(char.id, {
          x, y, z,
          displayName: char.id.toUpperCase(),
          texture: char.texture,
          health: char.health,
          damage: char.isFriendly ? 0 : char.damage,
          team: char.isFriendly ? "allies" : "enemy"
        });
      }
    }
  });
}

// === Run on Start ===
game.onWorldLoad(function() {
  spawnFruitMerchant(180, game.getSurfaceY(180, 200), 200);
  setInterval(spawnRandomCharactersAcrossOcean, 1200);
});
